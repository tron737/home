using NUnit.Framework;
using System;

namespace Test
{
	[TestFixture()]
	public class NUnitTestClass
	{
		[Test()]
		public void RectTestNegative()
		{
			Assert.AreEqual (Test.MainClass.Rect (-10, -10000), 0);
		}
		[Test()]
		public void RectTestP()
		{
			Assert.AreEqual (Test.MainClass.Rect (100, 10), 90);
		}
		[Test()]
		public void RectTest()
		{
			Assert.AreEqual (Test.MainClass.Rect (10, 1000), 0);
		}
		[Test()]
		public void OstTestNegative()
		{
			Assert.AreEqual (Test.MainClass.Ost (-1, -1), 0);
		}
	}
}


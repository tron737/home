using System;
using System.IO;
using System.Text.RegularExpressions;

namespace Test
{
	/// <summary>
	/// Main class.
	/// </summary>
	

	public class MainClass
	{
		public static void Main (string[] args)
		{
			try {
				//Console.WriteLine(StringAndDict("", ""));
				Console.Write("Enter file dictionary: ");
				string[] dict = File.ReadAllLines (Console.ReadLine());
				Console.Write("Enter file text: ");
				var text = File.ReadAllLines (Console.ReadLine());
				Console.Write("Enter N split lines at the file: ");
				int n = int.Parse(Console.ReadLine());
				string[] marks = {",", "."};
				if (n < 10){
					throw new System.DivideByZeroException();
				}

				for (int j = 0; j < text.Length; j += n) {
				var writer = new StreamWriter ("output-" + j + ".html");
				writer.Write ("<!DOCTYPE HTML>\n<html>\n<head>\n<title>Text</title>\n<meta charset='UTF-8'>\n</head>\n<body>\n");
				for (int index = Rect (j, n); index < j; index++) {
						string[] str = text [index].Split(' ');
						for(int p = 0; p < str.Length; p++) {
						for (int k = 0; k < dict.Length; k++) {
								if ((str[p] == dict[k]) || (str [p] == dict [k]+marks[0]) || (str [p] == dict [k]+marks[1])) {
								str [p] = "<b><i>" + str [p] + "</b></i>";
							}
						}
							writer.Write(str[p] + " ");
					}
					writer.Write ("<br>\n");
				}
					writer.WriteLine ("\n</body>\n</html>");
				}


				//обработаем остаток
				//text.Length - (text.Length - (text.Length / n) * n)
				if(Ost(n, text.Length) != text.Length) {
						var writer1 = new StreamWriter ("output-other.html");
						writer1.Write ("<!DOCTYPE HTML>\n<html>\n<head>\n<title>Text</title>\n<meta charset='UTF-8'>\n</head>\n<body>\n");
					for (int index = (text.Length / n) * n; index < text.Length; index++) {
						string[] str = text [index].Split(' ');
						for(int p = 0; p < str.Length; p++) {
							for (int k = 0; k < dict.Length; k++) {
								if ((str [p] == dict [k]) || (str [p] == dict [k]+marks[0]) || (str [p] == dict [k]+marks[1])) {
									str [p] = "<b><i>" + str [p] + "</b></i>";
								}
							}
							writer1.Write(str[p] + " ");
						}
						writer1.Write ("<br>\n");
						}
						writer1.WriteLine ("\n</body>\n</html>");
				}
			} catch(System.UnauthorizedAccessException e) {
				Console.WriteLine (e);
				throw;
			}

		}
		//формирование номера строки от которого нужно начинать обработку
		public static int Rect(int jj, int nn)
		{
			if (jj < 0 && nn < 0)
				return 0;
			if (jj - nn <= 0)
				return 0;
			else
				return jj - nn;
		}
		public static int Ost(int n, int length)
		{
			if (length < 0 && n < 0)
				return 0;
			return length - (length - (length / n) * n);
		}
	}
}
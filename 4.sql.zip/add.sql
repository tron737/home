CREATE PROCEDURE add(d CHAR(50), i CHAR(50), p CHAR(50), n CHAR(50))
begin
	INSERT INTO bd (date, id, postavshik, nachalnik) VALUE (d, i, p, n);
end

CREATE FUNCTION leader
begin
	SELECT COUNT(*) INTO bd
	FROM postavks = par_postavka
		RETURN (bd);
end

CREATE TRIGGER `premiya_add` BEFORE INSERT ON `bd`
begin
	if(select bd from COUNT(postavshik))
		UPDATE `bd` SET `premia` = `premia` + 5000
end